[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=22990360&assignment_repo_type=AssignmentRepo)
# GAMR1530 Coursework 2026
You are to build a ray tracer in JavaScript which uses the Phong Lighting model.
This repo will be your submission.

----------------------------
Coursework Readme
----------------------------

    How to run:
        Open index.html in a web browser and wait a moment for the program to render.
        (Please be patient, the increased resolution and sample count make it slightly slower.)

    What it does:
        This program creates rays that are projected from a camera. 
        These rays travel until they intersect with an object, then if it does it will fire an additional 'shadow' ray towards a light source. 
        If there is a clear line of sight to the light source, the pixel is illuminated in the object's colour, else it will be only partially illuminated by an ambient light, creating shadows. 
        If there is no intersection, the ray will return a background colour. This colour is decided by comparing the Y (vertical) value of that ray to a gradient colour.
        This is repeated ~24 times for each pixel, then the results are averaged to create a less jagged image. 
        Sampling more times creates a clearer and smoother image, at the cost of performance. (This is called anti-aliasing)

        This process is then repeated for every pixel in a 500 by 500 resolution pixel grid.
        Because this uses the Phong lighting model there is:
            Ambient lighting, used to help make darker areas still visible. This is set to 0.3 to keep shadows visible, without having them be solid black.
            Diffuse lighting, meaning parts that face the light source are brighter.
            Specular shading, adding a shining effect by making rays that are nearly parallel with the camera brighter.

        This comes together in the scene to create a lit scene with three coloured spheres, with a gradient background.